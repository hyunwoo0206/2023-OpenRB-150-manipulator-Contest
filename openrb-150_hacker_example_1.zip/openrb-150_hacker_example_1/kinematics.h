#include <math.h>

#define M_2PI (2.*M_PI)


inline double GetAngle2ndLawCos(double L1, double L2, double L3){
    return acos((L1*L1 + L2*L2 - L3*L3)/(2*L1*L2));
}


int GetJointAngle(double x, double y, double z, double pitch, double poAngle[4]) {
    double th[4] = {0, };
    double l1, l2, l3, l4;
    double l_tar, l_tmp1, l_tmp2;
    double l_z;
    double th2_0, th3_0, th2_1, th2_2, th4_1, th4_2, th4_3;

    // Link Length
    l1 = 68.;
    l2 = 85.7263086805911642;
    l3 = 82.;
    l4 = 78.;
    th2_0 = 0.2959260384642081;
    th3_0 = 1.2748702883306884;

    l_tar = sqrt(x*x + y*y);
    th[0] = atan2(y, x);

    l_tmp1 = l_tar - (l4 * cos(pitch));
    if((l2 + l3) < l_tmp1)  return 0;

    l_z = l4 * sin(pitch) + z - l1;
    l_tmp2 = sqrt(l_z*l_z + l_tmp1*l_tmp1);

    th2_1 = atan2(l_z, l_tmp1);
    th4_1 = M_PI_2 - pitch;
    th4_2 = M_PI_2 - th2_1;

    th2_2 = GetAngle2ndLawCos(l_tmp2, l2, l3);
    th[2] = GetAngle2ndLawCos(l2, l3, l_tmp2);
    th4_3 = GetAngle2ndLawCos(l3, l_tmp2, l2);

    th[1] = -(th2_0 + th2_1 + th2_2 - M_PI_2);
    th[2] = -(th[2] + th3_0 - M_PI);
    th[3] = -(th4_1 + th4_2 + th4_3 - M_PI);

    poAngle[0] = th[0];
    poAngle[1] = th[1];
    poAngle[2] = th[2];
    poAngle[3] = th[3];

    return 1;
}